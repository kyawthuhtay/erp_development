{ 
    'name': 'User interface improvements to the To-Do app',
    'description': 'User friendly features.',
    'author': 'Kyaw Thu Htay',
    'depends': [
        'todo_user'
        ],
    'data': [
        'todo_view.xml',
    ]
}