{ 
   'name': 'Multiuser To-Do',
   'description': 'Extend the To-Do app to multiuser.',
   'author': 'Kyaw Thu Htay',
   'depends': [
      'todo_app'
   ], 
   'data': [
      'todo_view.xml',
      'security/todo_access_rules.xml'
   ],
   'application': True,
}