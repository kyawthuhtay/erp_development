{ 
    'name': 'To-do Tasks Management Assistant',
    'description': 'Mass edit your To-Do backlog.',
    'author': 'Kyaw Thu Htay',
    'depends': ['todo_user'],
    'data': [
            'todo_wizard_view.xml'
        ]
}